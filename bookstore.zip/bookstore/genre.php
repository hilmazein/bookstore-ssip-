<?php
// Koneksi ke database
$host = 'localhost';
$username = 'root'; // Ganti dengan username database Anda
$password = ''; // Ganti dengan password database Anda
$database = 'bookstore'; // Ganti dengan nama database Anda

$koneksi = new mysqli($host, $username, $password, $database);

// Cek koneksi
if ($koneksi->connect_error) {
    die("Koneksi ke database gagal: " . $koneksi->connect_error);
}

// Fungsi untuk mendapatkan semua data genre
function getAllGenres($koneksi) {
    $sql = "SELECT * FROM genre";
    $result = $koneksi->query($sql);

    $genres = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $genres[] = $row;
        }
    }
    return $genres;
}

// Mendapatkan semua data genre
$genres = getAllGenres($koneksi);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Genre Management</title>
</head>
<body>
    <h1>List of Genres</h1>
    <ul>
        <?php foreach ($genres as $genre) : ?>
            <li><?php echo $genre['genreName']; ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>

<?php
// Tutup koneksi ke database
$koneksi->close();
?>
