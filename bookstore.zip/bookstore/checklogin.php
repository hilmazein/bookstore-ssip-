<?php
session_start();
if(isset($_POST['username']) && isset($_POST['pwd'])){
    $username = $_POST['username'];
    $pwd = $_POST['pwd'];

    include "connectDB.php"; // Assuming connectDB.php contains your database connection code
     
    $sql = "SELECT * FROM Users WHERE UserName = ? AND Password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $pwd);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if(mysqli_num_rows($result) > 0){
        while($row = $result->fetch_assoc()) {
            $_SESSION['id'] = $row['UserID'];
            break; // Assuming you only need the first row
        }
        header("Location: index.php");
        exit(); // Terminate script execution after redirection
    } else {
        echo '<span style="color: red;">Login Fail</span>';
        header("Location: login.php?errcode=1");
        exit(); // Terminate script execution after redirection
    }
}
?>
