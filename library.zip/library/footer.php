<?php
    echo '<footer class="text-center text-lg-start bg-white text-muted">
    <hr class="mt-4">
    <div class="text-center p-3">
        <span class="text-gray lead fs-6">&copy; 2024</span> 
        <span class="text-gray lead fs-6">Library Management System by HILARSON. All rights reserved</span>
    </div>
</footer>';

?>